
![Frame 6](https://github.com/user-attachments/assets/03f84b2d-a537-48a6-8efa-25326eb2b389)


# UX-Tracking: Web Extension

- [Como instala a extensão](#-como-instalar-a-extensão-ux-tracking-via-carregar-sem-compactação)

  Repositório da extensão web do framework [UX-Tracking: User eXperience Tracking](https://uxtracking.andrepereira.eng.br/)

## Tabela de conteúdos

- [Pré Requisitos](#pré-requisitos)
- [Topologia](#topologia)
- [Ambiente de desenvolvimento](#ambiente-de-desenvolvimento)
- [Utilização](#utilização)
- - [Distribuição](#distribuição)
- - [Ambiente de desenvolvimento](#ambiente-de-desenvolvimento)
- [Extensão](#Extensão)
- - [Cliente](#cliente)
- - - [Rastreamento de mouse](#rastreamento-de-mouse)
- - - [Rastreamento ocular](#rastreamento-ocular)
- - - [Keylogging](#keylogging)
- - - [Think aloud](#Transcrição-de-voz

## Pré-requisitos

📃 Para o desenvolvimento do projeto contido neste repositório, estabelecem-se os seguintes requisitos:

- [Visual Studio Code](https://code.visualstudio.com/download)
- [Google Chrome](https://www.google.com/chrome/)

## Topologia

- [popup](https://github.com/Colab-UNIRIO-UFPA/UX-Tracking-Extension/tree/master/popup) - `Popup exibido na extensão`
- index.html - `Página html do popup`
- script.js - `Script do popup`
- styles.css - `CSS da página do popup`
- [vendor](https://github.com/Colab-UNIRIO-UFPA/UX-Tracking-Extension/tree/master/vendor) - `Pasta para os scripts externos utilizados na extensão`
- browser-polyfill-0.10.0.min.js
- jquery-3.4.1.min.js
- background.js - `Script de background da extensão`
- content.js - `Script de conteúdo da extensão`
- logo.png - `Logo da extensão`
- main.js - `Script main da extensão`
- manifest.json - `Manifesto da extensão chrome`

## Extensão

Desenvolvido como uma extensão do navegador Google Chrome utilizando Javascript, esta extensão é responsável por capturar - do lado cliente - as interações dos usuários, no papel de usuários da aplicação web, a partir das técnicas de rastreamento do mouse, do olho e do teclado, além de transcrição de fala.

#### Rastreamento de mouse

A captura de interações do mouse contempla 4 tipos de interação:

- Movimento
- Clique
- Pausa

#### Rastreamento ocular

O rastreamento ocular é realizado por meio de uma versão modificada do [WebGazer](https://github.com/brownhci/WebGazer) (Copyright © 2016-2021, Brown HCI Group).

#### Keylogging

A extensão também pode capturar entradas de teclado, registrando a digitação de caracteres.

#### Transcrição de voz

Utilizando o [WebKit Voice Recognition](https://developer.mozilla.org/en-US/docs/Web/API/SpeechRecognition), o módulo cliente é capaz de capturar voz, incluindo pausas, transcrevendo e enviando como entradas de texto.

# 📦 Como instalar a extensão UX-Tracking via "Carregar sem compactação"

Este guia mostra como instalar a extensão **UX-Tracking** no Google Chrome em modo de desenvolvimento.

---

## 🧰 Pré-requisitos

- Google Chrome instalado.
- A pasta da extensão clonada ou descompactada em seu computador (ex: `uxtracking-extension-v2/`).

---

## 🚀 Passo a Passo

### 1. Acesse o menu de extensões

1. Abra o navegador Chrome.
2. Digite `chrome://extensions` na barra de endereço e pressione **Enter**.

---

### 2. Ative o modo desenvolvedor

No canto superior direito da tela, ative a chave chamada **Modo do desenvolvedor**.

### 3. Clique em "Carregar sem compactação"

Clique no botão `Carregar sem compactação`.

📸 **Imagem ilustrativa:**
![Ativar modo desenvolvedor](readmeImage/passo1.png)

---

### 4. Selecione a pasta da extensão

Navegue até a pasta onde estão os arquivos da extensão (ex: `uxtracking-extension/`) e clique em **Selecionar pasta**.

📸 **Imagem ilustrativa:**
![Ativar modo desenvolvedor](readmeImage/passo2.png)

---

### 5. Verifique se a extensão foi carregada

Após a seleção, a extensão aparecerá na lista de extensões ativas com o nome **UX-Tracking**.

📸 **Imagem ilustrativa:**
![Ativar modo desenvolvedor](readmeImage/passo3.png)

---
