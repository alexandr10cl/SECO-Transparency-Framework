// =========================
// UX-Tracking Popup (Clean-ish Single-File Architecture)
// =========================

/* 
  Organização:
  - UIManager ............. Somente UI (mostrar páginas, erros, marcação de inputs, status)
  - ApiService ............ Fetch + headers + tratamento básico de erro
  - StorageService ........ Acesso a chrome.storage.{local|sync}
  - AuthService ........... Fluxos de autenticação (login e login por código)
  - SessionService ........ Sincronização de sessão com o backend
  - RecordingService ...... Lidar com início/paro de gravação (mensagens ao background)
  - Router ................ Navegação entre telas
  - EventBinder ........... Registro de listeners em elementos do DOM
  - App ................... Orquestra tudo (estado, chamadas de serviços e UI)
  - Funções globais ....... Wrappers para manter nomes existentes (updateActiveCount, etc.)

  OBS: Mantidos os comportamentos do código original.
*/

/////////////////////////////
// TIMER SERVICE
/////////////////////////////

let timerInterval = null;

class TimerService {
  static startTimer(startTime) {
    TimerService.stopTimer();
    const mainTimer = document.getElementById('mainTimerDisplay');
    const codeTimer = document.getElementById('codeTimerDisplay');

    if (mainTimer) mainTimer.style.display = 'inline-block';
    if (codeTimer) codeTimer.style.display = 'inline-block';

    const updateUI = () => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      const h = String(Math.floor(elapsed / 3600)).padStart(2, '0');
      const m = String(Math.floor((elapsed % 3600) / 60)).padStart(2, '0');
      const s = String(elapsed % 60).padStart(2, '0');
      const text = `${h}:${m}:${s}`;
      if (mainTimer) mainTimer.textContent = text;
      if (codeTimer) codeTimer.textContent = text;
    };

    updateUI();
    timerInterval = setInterval(updateUI, 1000);
  }

  static stopTimer() {
    if (timerInterval) {
      clearInterval(timerInterval);
      timerInterval = null;
    }
    const mainTimer = document.getElementById('mainTimerDisplay');
    const codeTimer = document.getElementById('codeTimerDisplay');
    if (mainTimer) { mainTimer.style.display = 'none'; mainTimer.textContent = '00:00:00'; }
    if (codeTimer) { codeTimer.style.display = 'none'; codeTimer.textContent = '00:00:00'; }
  }
}

/////////////////////////////
// UI LAYER
/////////////////////////////

class UIManager {
  static showPage(pageId) {
    document.querySelectorAll(".page").forEach((page) => {
      page.classList.remove("active")
    })
    const targetPage = document.getElementById(pageId)
    if (targetPage) targetPage.classList.add("active")
  }

  static showError(containerId, message) {
    const errorContainer = document.getElementById(containerId)
    const errorText = document.getElementById(containerId.replace("Error", "ErrorText"))

    if (errorContainer && errorText) {
      errorText.textContent = message
      errorContainer.classList.add("show")
      setTimeout(() => {
        UIManager.hideError(containerId)
      }, 5000)
    }
  }

  static hideError(containerId) {
    const errorContainer = document.getElementById(containerId)
    if (errorContainer) errorContainer.classList.remove("show")
  }

  static clearAllErrors() {
    ;["loginError", "codeError", "sessionError"].forEach((errorId) => UIManager.hideError(errorId))
    document.querySelectorAll(".form-input.error").forEach((input) => input.classList.remove("error"))
  }

  static markInputError(inputId) {
    const input = document.getElementById(inputId)
    if (input) input.classList.add("error")
  }

  // ---- Status e contadores
  static updateActiveCount() {
    const checkboxes = document.querySelectorAll('.switch-grid input[type="checkbox"]')
    const activeCount = Array.from(checkboxes).filter((cb) => cb.checked).length
    const counter = document.getElementById("activeControlsCount")
    if (counter) counter.textContent = `${activeCount} ${t('active')}`
  }

  static updateRecordingStatus(isOn) {
    const statusDot = document.getElementById("sessionStatusDot")
    const statusText = document.getElementById("sessionStatusText")
    if (isOn) {
      if (statusDot) statusDot.style.background = "var(--error)"
      if (statusText) statusText.textContent = t('recording')
    } else {
      if (statusDot) statusDot.style.background = "var(--success)"
      if (statusText) statusText.textContent = t('activeSession')
    }
  }

  static updateCodeRecordingStatus(isOn) {
    const statusDot = document.getElementById("codeStatusDot")
    const statusText = document.getElementById("codeStatusText")
    if (isOn) {
      if (statusDot) statusDot.style.background = "var(--error)"
      if (statusText) statusText.textContent = t('recording')
    } else {
      if (statusDot) statusDot.style.background = "var(--success)"
      if (statusText) statusText.textContent = t('activeSession')
    }
  }

  static setSubmitButtonState({ text, bg, disabled, display }) {
    const submitButton = document.getElementById("__StartCodeButton__")
    if (!submitButton) return
    if (typeof text === "string") submitButton.textContent = text
    if (bg) submitButton.style.background = bg
    if (typeof disabled === "boolean") submitButton.disabled = disabled
    if (display) submitButton.style.display = display
  }

  static setCodeUIActive(codeValue) {
    const codeField = document.getElementById("codeSessionB")
    if (codeField) {
      codeField.value = codeValue || ""
      codeField.disabled = true
    }
    const status = document.getElementById("codeSessionStatus")
    const stopBtn = document.getElementById("__StopCodeButton__")
    if (status) status.style.display = "flex"
    if (stopBtn) stopBtn.style.display = "block"
    UIManager.setSubmitButtonState({ text: t('sessionActive'), bg: "var(--success)", disabled: true, display: "none" })
  }

  static resetCodeUI() {
    const codeField = document.getElementById("codeSessionB")
    if (codeField) {
      codeField.disabled = false
      codeField.value = ""
    }
    const status = document.getElementById("codeSessionStatus")
    const stopBtn = document.getElementById("__StopCodeButton__")
    if (status) status.style.display = "none"
    if (stopBtn) stopBtn.style.display = "none"
    UIManager.setSubmitButtonState({ text: t('startSession'), bg: "var(--gradient-btn)", disabled: false, display: "block" })
  }
}

/////////////////////////////
// CONFIG & SHARED STATE
/////////////////////////////

const API_CONFIG = {
  baseUrl: "https://uxt.liis.com.br",
  endpoints: {
    login: "/auth/login",
    codeLogin: "/auth/login-code",
    syncSession: "/data/syncsession",
    logout: "/auth/logout",
  },
}

// Estado compartilhado (mantendo variáveis originais)
let isCodeSession = false
let authToken = null
let sessionId = null
let isRecording = false
let currentCode = null
let authID = null
const chrome = window.chrome

/////////////////////////////
// INFRA SERVICES
/////////////////////////////

class ApiService {
  constructor(config) {
    this.baseUrl = config.baseUrl
    this.endpoints = config.endpoints
  }

  async request(endpoint, options = {}, token = null) {
    try {
      const url = `${this.baseUrl}${endpoint}`
      const defaultOptions = {
        headers: {
          "Content-Type": "application/json",
          ...(token && { Authorization: `Bearer ${token}` }),
        },
      }
      const response = await fetch(url, { ...defaultOptions, ...options })
      if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`)
      return await response.json()
    } catch (err) {
      console.error("[log] Erro na requisição:", err)
      throw err
    }
  }
}

class StorageService {
  static get(keys, cb) { chrome.storage.sync.get(keys, cb) }
  static set(obj, cb) { chrome.storage.sync.set(obj, cb) }
  static remove(keys, cb) { chrome.storage.sync.remove(keys, cb) }
}

/////////////////////////////
// DOMAIN SERVICES
/////////////////////////////

class AuthService {
  constructor(api) {
    this.api = api
  }

  async login(email, password) {
    return this.api.request(API_CONFIG.endpoints.login, {
      method: "POST",
      body: JSON.stringify({ email, password }),
    })
  }

  async codeLogin(code, pageHref) {
    return this.api.request(API_CONFIG.endpoints.codeLogin, {
      method: "POST",
      body: JSON.stringify({
        userId: "0",
        tool: "UX-Tracking Extension",
        initialMetadata: { pageUrl: pageHref || "https://exemplo.com/extensao" },
        integration: { cod: code },
      }),
    })
  }

  async logout(token) {
    if (!token) return
    try {
      await this.api.request(API_CONFIG.endpoints.logout, { method: "POST" }, token)
    } catch (e) {
      console.error("[log] Erro no logout:", e)
    }
  }
}

class SessionService {
  constructor(api) {
    this.api = api
  }

  async syncSession(code, token) {
    return this.api.request(API_CONFIG.endpoints.syncSession, {
      method: "POST",
      body: JSON.stringify({ cod: code }),
    }, token)
  }
}

class RecordingService {
  static async startCodeReceiver() {
    try {
      console.log("[log] Iniciando receiver com sessionId:", sessionId)

      const recordCheckbox = document.getElementById("__listen_record__")
      if (recordCheckbox) {
        recordCheckbox.checked = true
        console.log("[log] Checkbox de gravação ativado automaticamente")
      }

      isRecording = true

      StorageService.set({
        authToken,
        sessionId,
        isCodeSession: true,
        currentCode,
        record: true,
      })

      // Mesmo com o botão oculto em certos fluxos, mantemos a linha como no original
      UIManager.setSubmitButtonState({
        text: t('endSession'),
        bg: "rgba(255, 0, 4, 1)",
        disabled: true,
      })

      UIManager.updateRecordingStatus(true)
      UIManager.updateCodeRecordingStatus(true)

      const startTime = Date.now();
      chrome.storage.local.set({ recordingStartTime: startTime });
      TimerService.startTimer(startTime);

      console.log("[log] Enviando notificação de captura...")
      chrome.runtime.sendMessage({ type: "showCaptureNotification" })

      console.log("[log] Enviando comando para iniciar gravação...")
      chrome.runtime.sendMessage({ type: "startRecordingCode" })

      console.log("[log] Receiver iniciado com sucesso")
    } catch (error) {
      console.error("[log] Erro ao iniciar receiver:", error)
      UIManager.showError("codeError", t('captureError'))
    }
  }

  static async stopCodeRecording() {
    try {
      console.log("[log] Encerrando gravação...")

      chrome.runtime.sendMessage({ type: "stopRecording" })

      isRecording = false
      isCodeSession = false
      currentCode = null

      UIManager.resetCodeUI()
      UIManager.updateRecordingStatus(false)
      UIManager.updateCodeRecordingStatus(false)

      chrome.storage.local.remove(["recordingStartTime"])
      TimerService.stopTimer()

      StorageService.remove(["authToken", "sessionId", "isCodeSession", "currentCode"])

      console.log("[log] Gravação encerrada com sucesso")
    } catch (error) {
      console.error("[log] Erro ao encerrar gravação:", error)
    }
  }
}

/////////////////////////////
// ROUTER
/////////////////////////////

class Router {
  static goToLogin() { UIManager.showPage("divLogin") }
  static goToMain() { UIManager.showPage("mainContent") }
  static goToCodeAccess() { UIManager.showPage("mainContentCodeAcess") }
}

/////////////////////////////
// EVENT BINDER
/////////////////////////////

class EventBinder {
  constructor(app) {
    this.app = app
  }

  bind() {
    // Login
    const formLogin = document.getElementById("formLogin")
    if (formLogin) {
      formLogin.addEventListener("submit", (e) => this.app.handleLoginSubmit(e))
    }

    // Acesso por código (entrar na tela)
    const accessByCodeLogin = document.getElementById("accessByCodeLogin")
    if (accessByCodeLogin) {
      accessByCodeLogin.addEventListener("click", (e) => this.app.handleAccessByCodeLoginClick(e))
    }

    // Voltar para login a partir da tela de código
    const accessByCodeCode = document.getElementById("accessByCodeCode")
    if (accessByCodeCode) {
      accessByCodeCode.addEventListener("click", (e) => this.app.handleAccessByCodeCodeClick(e))
    }

    // Submit do formulário de sessão por código
    const formSession = document.getElementById("formSessionB")
    if (formSession) {
      formSession.addEventListener("submit", (e) => this.app.handleSessionFormSubmit(e))
    }

    // Mostrar/ocultar senha
    document.querySelectorAll(".password-toggle").forEach((button) => {
      button.addEventListener("click", function () {
        console.log("[log] Toggle de senha clicado")
        const targetId = this.getAttribute("data-target")
        const input = document.getElementById(targetId)
        if (input.type === "password") {
          input.type = "text"
          this.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>'
        } else {
          input.type = "password"
          this.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>'
        }
      })
    })

    // Switches de captura
    document.querySelectorAll('.switch-grid input[type="checkbox"]').forEach((checkbox) => {
      checkbox.addEventListener("change", () => UIManager.updateActiveCount())
    })

    // Checkbox de gravação
    const recordCheckbox = document.getElementById("__listen_record__")
    if (recordCheckbox) {
      recordCheckbox.addEventListener("change", () => {
        const isOn = recordCheckbox.checked
        UIManager.updateRecordingStatus(isOn)
        if (isOn) {
          const startTime = Date.now()
          chrome.storage.local.set({ recordingStartTime: startTime })
          TimerService.startTimer(startTime)
        } else {
          chrome.storage.local.remove(["recordingStartTime"])
          TimerService.stopTimer()
        }
      })
    }

    // Logout
    const logoutButton = document.getElementById("logout")
    if (logoutButton) {
      logoutButton.addEventListener("click", (e) => this.app.handleLogout(e))
    }

    // Forgot / Register
    const forgotPassButton = document.getElementById("forgotPass")
    if (forgotPassButton) {
      forgotPassButton.addEventListener("click", (e) => {
        e.preventDefault()
        const emailInput = document.getElementById("username")
        const email = emailInput && emailInput.value.trim()
        let url = "https://uxtracking.liis.com.br/esqueci-senha"
        if (email) {
          url += `?email=${encodeURIComponent(email)}`
        }
        chrome.tabs.create({ url })
      })
    }

    const registerButton = document.getElementById("register")
    if (registerButton) {
      registerButton.addEventListener("click", (e) => {
        e.preventDefault()
        chrome.tabs.create({ url: "https://uxtracking.liis.com.br/cadastro" })
      })
    }

    const stopCodeButton = document.getElementById("__StopCodeButton__")
    if (stopCodeButton) {
      stopCodeButton.addEventListener("click", async (e) => {
        e.preventDefault()
        await RecordingService.stopCodeRecording()
      })
    }
  }
}

/////////////////////////////
// APP (ORCHESTRATION)
/////////////////////////////

class App {
  constructor() {
    this.api = new ApiService(API_CONFIG)
    this.auth = new AuthService(this.api)
    this.session = new SessionService(this.api)
    this.events = new EventBinder(this)
  }

  init() {
    console.log("[log] DOM loaded, initializing app...")
    this.events.bind()
    this.restoreFromStorage()

    chrome.storage.sync.get(['record'], (syncRes) => {
      if (syncRes.record) {
        chrome.storage.local.get(['recordingStartTime'], (localRes) => {
          if (localRes.recordingStartTime) {
            TimerService.startTimer(localRes.recordingStartTime);
          } else {
            const now = Date.now();
            chrome.storage.local.set({ recordingStartTime: now });
            TimerService.startTimer(now);
          }
        });
      }
    });
  }

  // ---- Handlers

  async handleLoginSubmit(e) {
    e.preventDefault()
    UIManager.clearAllErrors()

    const username = document.getElementById("username").value.trim()
    const password = document.getElementById("password").value.trim()

    if (!username || !password) {
      UIManager.showError("loginError", t('fillAllFields'))
      if (!username) UIManager.markInputError("username")
      if (!password) UIManager.markInputError("password")
      return
    }

    try {
      const data = await this.auth.login(username, password)
      if (data.status === 200 && data.access_token) {
        authToken = data.access_token
        sessionId = null
        isCodeSession = false
        authID = data.id
        // 
        StorageService.set({ authToken, sessionId, isCodeSession, authID })

        console.log("[log] Login bem-sucedido, navegando para sessão ativa")
        Router.goToMain()
        UIManager.clearAllErrors()
        UIManager.updateActiveCount()
        UIManager.updateRecordingStatus(false)
      } else {
        UIManager.showError("loginError", data.message || t('authFailed'))
        UIManager.markInputError("username")
        UIManager.markInputError("password")
      }
    } catch (error) {
      console.error("[log] Erro no login real, tentando fallback:", error)
      if (
        (username === "admin" && password === "123456") ||
        (username === "demo" && password === "demo") ||
        (username === "test" && password === "test")
      ) {
        authToken = `local_${Date.now()}`
        Router.goToMain()
        UIManager.clearAllErrors()
        UIManager.updateActiveCount()
        UIManager.updateRecordingStatus(false)
      } else {
        UIManager.showError("loginError", t('wrongCredentials'))
        UIManager.markInputError("username")
        UIManager.markInputError("password")
      }
    }
  }

  handleAccessByCodeLoginClick(e) {
    e.preventDefault()
    console.log("[log] Clique em 'Iniciar com código' detectado")
    UIManager.clearAllErrors()
    Router.goToCodeAccess()
    isCodeSession = true
  }

  async handleAccessByCodeCodeClick(e) {
    e.preventDefault()
    console.log("[log] Voltando para login")

    if (isRecording && isCodeSession) {
      console.log("[log] Encerrando gravação antes de voltar ao login")
      await RecordingService.stopCodeRecording()
    }

    UIManager.clearAllErrors()
    Router.goToLogin()
    isCodeSession = false
    currentCode = null
    chrome.storage.local.remove(["authToken", "sessionId", "isCodeSession", "currentCode"])
  }

  async handleSessionFormSubmit(e) {
    e.preventDefault()
    UIManager.clearAllErrors()

    const codeSession = document.getElementById("codeSessionB").value.trim()

    if (!codeSession) {
      UIManager.showError("codeError", t('enterCode'))
      UIManager.markInputError("codeSessionB")
      return
    }
    if (codeSession.length < 4) {
      UIManager.showError("codeError", t('codeMinLength'))
      UIManager.markInputError("codeSessionB")
      return
    }

    const submitButton = document.getElementById("__StartCodeButton__")
    const originalText = submitButton.textContent
    submitButton.textContent = t('connecting')
    submitButton.disabled = true

    try {
      const codeLoginData = await this.auth.codeLogin(codeSession, window.location.href)
      if (codeLoginData.status === 200 && codeLoginData.access_token) {
        authToken = codeLoginData.access_token
        const syncData = await this.session.syncSession(codeSession, authToken)

        if (syncData.status === 200 && syncData.success && syncData.sessionId) {
          sessionId = syncData.sessionId
          isCodeSession = true
          currentCode = codeSession

          StorageService.set({
            authToken, sessionId, isCodeSession: true, currentCode: codeSession,
            authID: codeLoginData.userId
          })

          console.log("[log] Código válido e sessão sincronizada, mantendo na tela de código")
          UIManager.setCodeUIActive(codeSession)

          // Iniciar receiver automaticamente
          console.log("[log] Iniciando receiver automaticamente...")
          await RecordingService.startCodeReceiver()
        } else {
          submitButton.textContent = originalText
          submitButton.disabled = false
          UIManager.showError("codeError", syncData.message || t('syncError'))
          UIManager.markInputError("codeSessionB")
        }
      } else {
        submitButton.textContent = originalText
        submitButton.disabled = false
        UIManager.showError("codeError", codeLoginData.message || t('invalidCode'))
        UIManager.markInputError("codeSessionB")
      }
    } catch (error) {
      console.error("[log] Erro no login por código real, tentando fallback:", error)

      const validCodes = ["1234", "demo", "test", "admin", "session"]
      if (validCodes.includes(codeSession.toLowerCase())) {
        authToken = `code_${Date.now()}`
        sessionId = Math.floor(Math.random() * 1000)
        isCodeSession = true
        currentCode = codeSession

        // Mantém exatamente o uso de storage.local aqui (fallback)
        StorageService.localSet({ authToken, sessionId, isCodeSession: true, currentCode: codeSession })

        console.log("[log] Código válido (fallback), mantendo na tela de código")
        UIManager.setCodeUIActive(codeSession)

        console.log("[log] Iniciando receiver automaticamente (fallback)...")
        await RecordingService.startCodeReceiver()
      } else {
        submitButton.textContent = originalText
        submitButton.disabled = false
        UIManager.showError("codeError", t('invalidCodeRetry'))
        UIManager.markInputError("codeSessionB")
      }
    }
  }

  async handleLogout(e) {
    e.preventDefault()
    console.log("[log] Logout executado")
    try {
      if (authToken) await this.auth.logout(authToken)
    } finally {
      authToken = null
      sessionId = null
      isCodeSession = false
      StorageService.remove(["authToken", "sessionId", "isCodeSession"])
      Router.goToLogin()
      UIManager.clearAllErrors()
      const u = document.getElementById("username")
      const p = document.getElementById("password")
      const c = document.getElementById("codeSessionB")
      if (u) u.value = ""
      if (p) p.value = ""
      if (c) c.value = ""
    }
  }

  restoreFromStorage() {
    StorageService.get(["authToken", "sessionId", "isCodeSession", "currentCode"], (result) => {
      if (result.authToken) {
        authToken = result.authToken
        sessionId = result.sessionId || null
        isCodeSession = result.isCodeSession || false
        currentCode = result.currentCode || null

        console.log("[log] Token encontrado no storage...")

        if (isCodeSession) {
          console.log("[log] Sessão por código detectada, mostrando tela de código")
          Router.goToCodeAccess()

          UIManager.setSubmitButtonState({ text: t('sessionActive'), bg: "var(--success)", disabled: true, display: "none" })

          const codeField = document.getElementById("codeSessionB")
          if (codeField && currentCode) {
            codeField.value = currentCode
            codeField.disabled = true
          }

          const status = document.getElementById("codeSessionStatus")
          const stopBtn = document.getElementById("__StopCodeButton__")
          if (status) status.style.display = "flex"
          if (stopBtn) stopBtn.style.display = "block"
        } else {
          Router.goToMain()
          UIManager.updateActiveCount()
          UIManager.updateRecordingStatus(false)
        }
      } else {
        console.log("[log] Nenhum token encontrado, mostrando tela de login")
        Router.goToLogin()
      }
    })
  }
}

/////////////////////////////
// WRAPPERS (mantêm nomes globais originais)
/////////////////////////////

function updateActiveCount() {
  UIManager.updateActiveCount()
}

function updateRecordingStatus() {
  const recordCheckbox = document.getElementById("__listen_record__")
  const isOn = !!(recordCheckbox && recordCheckbox.checked)
  UIManager.updateRecordingStatus(isOn)
}

function updateCodeRecordingStatus() {
  UIManager.updateCodeRecordingStatus(isRecording)
}

async function startCodeReceiver() {
  await RecordingService.startCodeReceiver()
}

async function stopCodeRecording() {
  await RecordingService.stopCodeRecording()
}

/////////////////////////////
// BOOTSTRAP
/////////////////////////////

document.addEventListener("DOMContentLoaded", () => {
  const app = new App()
  app.init()
})
