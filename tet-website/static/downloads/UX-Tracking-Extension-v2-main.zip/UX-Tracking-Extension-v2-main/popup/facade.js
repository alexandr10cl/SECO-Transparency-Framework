import { handleInitialSessionState } from "./services/handleInitialSessionState.service.js";
import linksService from "./services/links.service.js";
import {loginService} from "./services/login.service.js";
import { loginCodeService } from "./services/loginCode.service.js";
import logoutService from "./services/logout.service.js";
import {notification_login} from "./services/notification.service.js";
import switchModeLoginCode from "./services/switchModeLoginCode.service.js";
import { getBaseUrl } from "./utils/getBaseUrl.js";
import { getSessionData } from "./utils/getSessionData.js";

let isCodeSession = false;

document.addEventListener('DOMContentLoaded', () => {

  Promise.all([getBaseUrl(), getSessionData()]).then(([url, data]) => {
    handleInitialSessionState(data)
    notification_login();
    loginService()
  });

  document.getElementById('accessByCodeLogin').addEventListener('click', function (e) {
    e.preventDefault();
    document.getElementById('divLogin').style.display = "none";
    document.getElementById('mainContentCodeAcess').style.display = "block";
    isCodeSession = true;
  });

  document.getElementById('accessByCodeCode').addEventListener('click', function (e) {
    e.preventDefault();
    document.getElementById('divLogin').style.display = "block";
    document.getElementById('mainContentCodeAcess').style.display = "none";
    isCodeSession = false;
  });

  const formSession = $('#formSessionB');
  formSession.submit(async function (e) {
    e.preventDefault();
  
    const session = await getSessionData();
    if (session.isCodeSession ?? false) {
      await switchModeLoginCode(session.isCodeSession);
      return;
    }
  
    const result = await loginCodeService(false);
    await switchModeLoginCode(result);
  });

  linksService();
});

logoutService();
