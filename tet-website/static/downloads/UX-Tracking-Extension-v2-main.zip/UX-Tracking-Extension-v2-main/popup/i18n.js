const i18n = {
    pt: {
        loginSubtitle: 'Entre na sua conta para continuar',
        email: 'Email', emailPlaceholder: 'seu@email.com',
        password: 'Senha', passwordPlaceholder: 'Sua senha',
        login: 'Entrar', or: 'ou',
        startWithCode: 'Iniciar com código de sessão',
        forgotPass: 'Esqueceu a senha?', register: 'Criar nova conta',
        codeAccess: 'Acesso por código', sessionCode: 'Código da sessão',
        codePlaceholder: 'Digite o código da sessão',
        collectedInteractions: 'Interações coletadas',
        mouse: 'Mouse', keyboard: 'Teclado', microphone: 'Microfone', camera: 'Câmera',
        startSession: 'Iniciar sessão', stopRecording: 'Parar gravação',
        backToLogin: '← Voltar ao login',
        activeSession: 'Sessão ativa', captureControls: 'Controles de captura',
        activeRecording: 'Gravação ativa', logout: 'Sair da conta',
        active: 'ativos',
        // Dynamic strings (facade.js)
        fillAllFields: 'Por favor, preencha todos os campos',
        authFailed: 'Falha na autenticação',
        wrongCredentials: 'Usuário ou senha incorretos',
        enterCode: 'Por favor, insira o código da sessão',
        codeMinLength: 'O código deve ter pelo menos 4 caracteres',
        connecting: 'Conectando...',
        syncError: 'Erro ao sincronizar sessão',
        invalidCode: 'Código inválido',
        invalidCodeRetry: 'Código inválido. Tente novamente',
        sessionActive: 'Sessão Ativa',
        recording: 'Gravando...',
        endSession: 'Encerrar sessão',
        captureError: 'Erro ao iniciar captura de dados'
    },
    en: {
        loginSubtitle: 'Sign in to your account to continue',
        email: 'Email', emailPlaceholder: 'you@email.com',
        password: 'Password', passwordPlaceholder: 'Your password',
        login: 'Sign in', or: 'or',
        startWithCode: 'Start with session code',
        forgotPass: 'Forgot password?', register: 'Create new account',
        codeAccess: 'Code access', sessionCode: 'Session code',
        codePlaceholder: 'Enter session code',
        collectedInteractions: 'Collected interactions',
        mouse: 'Mouse', keyboard: 'Keyboard', microphone: 'Microphone', camera: 'Camera',
        startSession: 'Start session', stopRecording: 'Stop recording',
        backToLogin: '← Back to login',
        activeSession: 'Active session', captureControls: 'Capture controls',
        activeRecording: 'Active recording', logout: 'Sign out',
        active: 'active',
        // Dynamic strings (facade.js)
        fillAllFields: 'Please fill in all fields',
        authFailed: 'Authentication failed',
        wrongCredentials: 'Incorrect username or password',
        enterCode: 'Please enter the session code',
        codeMinLength: 'Code must be at least 4 characters',
        connecting: 'Connecting...',
        syncError: 'Error syncing session',
        invalidCode: 'Invalid code',
        invalidCodeRetry: 'Invalid code. Try again',
        sessionActive: 'Active Session',
        recording: 'Recording...',
        endSession: 'End session',
        captureError: 'Error starting data capture'
    }
};
let currentLang = 'pt';

// Global translation helper for facade.js
window.t = function(key) { return (i18n[currentLang] && i18n[currentLang][key]) || key; };

function toggleLanguage() {
    currentLang = currentLang === 'pt' ? 'en' : 'pt';
    applyLanguage();
    try { window.chrome.storage.sync.set({ lang: currentLang }); } catch(e) {}
}

function applyLanguage() {
    const t = i18n[currentLang];
    const btnLabel = currentLang === 'pt' ? 'EN' : 'PT';
    document.querySelectorAll('.lang-toggle, .login-lang-toggle').forEach(b => b.textContent = btnLabel);

    // Login page
    const subtitle = document.querySelector('.login-subtitle');
    if (subtitle) subtitle.textContent = t.loginSubtitle;
    const emailLabel = document.querySelector('label[for="username"]');
    if (emailLabel) emailLabel.textContent = t.email;
    const emailInput = document.getElementById('username');
    if (emailInput) emailInput.placeholder = t.emailPlaceholder;
    const passLabel = document.querySelector('label[for="password"]');
    if (passLabel) passLabel.textContent = t.password;
    const passInput = document.getElementById('password');
    if (passInput) passInput.placeholder = t.passwordPlaceholder;
    const loginBtn = document.getElementById('c');
    if (loginBtn) loginBtn.textContent = t.login;
    const dividerSpan = document.querySelector('.divider span');
    if (dividerSpan) dividerSpan.textContent = t.or;
    const codeLink = document.getElementById('accessByCodeLogin');
    if (codeLink) codeLink.textContent = t.startWithCode;
    const forgotLink = document.getElementById('forgotPass');
    if (forgotLink) forgotLink.textContent = t.forgotPass;
    const registerLink = document.getElementById('register');
    if (registerLink) registerLink.textContent = t.register;

    // Code page
    const codeSub = document.querySelector('#mainContentCodeAcess .brand-subtitle');
    if (codeSub) codeSub.textContent = t.codeAccess;
    const codeLabel = document.querySelector('label[for="codeSessionB"]');
    if (codeLabel) codeLabel.textContent = t.sessionCode;
    const codeInput = document.getElementById('codeSessionB');
    if (codeInput) codeInput.placeholder = t.codePlaceholder;
    const secTitle = document.querySelector('#mainContentCodeAcess .section-title');
    if (secTitle) secTitle.textContent = t.collectedInteractions;
    const startBtn = document.getElementById('__StartCodeButton__');
    if (startBtn && !startBtn.disabled) startBtn.textContent = t.startSession;
    const stopBtn = document.getElementById('__StopCodeButton__');
    if (stopBtn) stopBtn.textContent = t.stopRecording;
    const backLink = document.getElementById('accessByCodeCode');
    if (backLink) backLink.textContent = t.backToLogin;

    // Main page
    const mainSub = document.querySelector('#mainContent .brand-subtitle');
    if (mainSub) mainSub.textContent = t.activeSession;
    const capTitle = document.querySelector('.card-title');
    if (capTitle) capTitle.textContent = t.captureControls;
    const recLabel = document.querySelector('.record-label');
    if (recLabel) recLabel.textContent = t.activeRecording;
    const logoutBtn = document.getElementById('logout');
    if (logoutBtn) logoutBtn.textContent = t.logout;

    // Shared labels
    document.querySelectorAll('[data-i18n="keyboard"]').forEach(el => {
        const svg = el.querySelector('svg');
        el.textContent = '';
        if (svg) { el.appendChild(svg); el.append(' '); }
        el.append(t.keyboard);
    });
    document.querySelectorAll('[data-i18n="microphone"]').forEach(el => {
        const svg = el.querySelector('svg');
        el.textContent = '';
        if (svg) { el.appendChild(svg); el.append(' '); }
        el.append(t.microphone);
    });
    document.querySelectorAll('[data-i18n="camera"]').forEach(el => {
        const svg = el.querySelector('svg');
        el.textContent = '';
        if (svg) { el.appendChild(svg); el.append(' '); }
        el.append(t.camera);
    });

    // Active count
    const counter = document.getElementById('activeControlsCount');
    if (counter) {
        const n = counter.textContent.match(/\d+/);
        if (n) counter.textContent = n[0] + ' ' + t.active;
    }
}

// Restore saved language and setup events
document.addEventListener('DOMContentLoaded', () => {
    // Set up click listeners
    document.querySelectorAll('.lang-toggle, .login-lang-toggle').forEach(btn => {
        btn.addEventListener('click', toggleLanguage);
    });

    try {
        window.chrome.storage.sync.get(['lang'], (r) => {
            if (r && r.lang) { currentLang = r.lang; applyLanguage(); }
        });
    } catch(e) {}
});
