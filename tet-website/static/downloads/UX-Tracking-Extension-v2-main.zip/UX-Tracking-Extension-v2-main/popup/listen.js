document.addEventListener("DOMContentLoaded", () => {
  // Storage utilities
  const StorageManager = {
    setKey(element, key) {
      const isChecked = element.target.checked
      window.chrome.storage.sync.set({ [key]: isChecked }).catch(console.error)
    },

    getKey(elementId, key) {
      window.chrome.storage.sync.get([key]).then((result) => {
        const element = document.getElementById(elementId)
        if (element) {
          element.checked = !!result[key]
        }
      })
    },
  }

  // Initialize storage values
  const initializeStorageValues = () => {
    const storageKeys = [
      { id: "__listen_mouse__", key: "mouse" },
      { id: "__listen_mouse__code", key: "mouse" },
      { id: "__listen_keyboard__", key: "keyboard" },
      { id: "__listen_keyboard__code", key: "keyboard" },
      { id: "__listen_microphone__", key: "microphone" },
      { id: "__listen_microphone__code", key: "microphone" },
      { id: "__listen_camera__", key: "camera" },
      { id: "__listen_camera__code", key: "camera" },
      { id: "__listen_record__", key: "record" },
    ]

    storageKeys.forEach(({ id, key }) => {
      StorageManager.getKey(id, key)
    })
  }

  // Event listeners setup
  const setupEventListeners = () => {
    const eventMappings = [
      { id: "__listen_mouse__", key: "mouse" },
      { id: "__listen_mouse__code", key: "mouse" },
      { id: "__listen_keyboard__", key: "keyboard" },
      { id: "__listen_keyboard__code", key: "keyboard" },
      { id: "__listen_microphone__", key: "microphone" },
      { id: "__listen_microphone__code", key: "microphone" },
      { id: "__listen_camera__", key: "camera" },
      { id: "__listen_camera__code", key: "camera" },
    ]

    eventMappings.forEach(({ id, key }) => {
      const element = document.getElementById(id)
      if (element) {
        element.addEventListener("change", (e) => {
          StorageManager.setKey(e, key)
        })
      }
    })

    // Special handling for record button
    const recordElement = document.getElementById("__listen_record__")
    if (recordElement) {
      recordElement.addEventListener("change", (e) => {
        const messageType = e.target.checked ? "startRecording" : "stopRecording"
        window.chrome.runtime.sendMessage({ type: messageType })
        StorageManager.setKey(e, "record")
      })
    }
  }

  // Initialize everything
  initializeStorageValues()
  setupEventListeners()
})
