export const getBaseUrl = () =>
    new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "getServerUrl" }, (response) => {
        document.getElementById('forgotPass').href = response.reply + "/forgot_pass";
        document.getElementById('register').href = response.reply + "/register";
        resolve(response.reply);
      });
    });