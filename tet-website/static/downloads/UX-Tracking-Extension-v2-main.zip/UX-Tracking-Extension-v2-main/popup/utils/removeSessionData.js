export default function removeSessionData() {
    return new Promise((resolve) => {
      chrome.storage.sync.remove(["authToken", "isCodeSession", "record", "codeSession", "sessionId"], resolve);
    });
  }