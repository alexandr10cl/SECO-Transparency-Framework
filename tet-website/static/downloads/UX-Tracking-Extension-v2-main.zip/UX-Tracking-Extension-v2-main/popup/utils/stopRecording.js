
export default async function stopRecording(action) {
    chrome.runtime.sendMessage({ type: "stopRecording" });
  }