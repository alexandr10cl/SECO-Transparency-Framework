export const getSessionData = () =>
    new Promise((resolve) => {
      chrome.storage.sync.get(['authToken', 'authID', 'isCodeSession', 'codeSession', 'sessionId'], (data) => resolve(data));
    });