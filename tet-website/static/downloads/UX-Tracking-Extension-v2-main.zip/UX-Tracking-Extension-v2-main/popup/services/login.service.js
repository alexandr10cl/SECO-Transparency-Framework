import { getBaseUrl } from "../utils/getBaseUrl.js";

export async function loginService() {
  let baseUrl = await getBaseUrl()
    const formLogin = $('#formLogin');
      formLogin.submit(function (e) {
        e.preventDefault();
        const email = $("#username").val();
        const password = $("#password").val();
  
        $.post(baseUrl + "/auth/login", { email, password }, function (data) {
          if (data.status === 200) {
            chrome.storage.sync.set({
              "authToken": data.access_token,
              "authID": data.id
            });
  
            document.getElementById("divLogin").style.display = "none";
            document.getElementById("mainContent").style.display = "block";
          } else {
            const existing = document.getElementById('errorLogin');
            if (existing) existing.remove();
  
            const div = document.createElement('div');
            div.style.color = 'red';
            div.id = 'errorLogin';
            div.textContent = 'Verifique seu nome de usuário e senha e tente novamente';
            document.getElementById('login').insertAdjacentElement('beforebegin', div);
          }
        });
      });
  }   
  
  