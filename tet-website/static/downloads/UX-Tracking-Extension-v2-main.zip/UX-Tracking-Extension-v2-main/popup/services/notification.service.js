export function notification_login() {
    chrome.notifications.create('loginNotification', {
      type: 'basic',
      iconUrl: 'logo.png',
      title: 'UX-Tracking: Login necessário!',
      message: 'Faça o login para iniciar a captura!\nClique no botão abaixo ou abra o menu da extensão.',
      buttons: [{ title: 'Fazer login' }]
    });
  
    chrome.notifications.onButtonClicked.addListener(function (clickedNotificationId, buttonIndex) {
      if (clickedNotificationId === 'loginNotification' && buttonIndex === 0) {
        chrome.windows.create({
          url: 'popup/index.html',
          type: 'popup',
          width: 300,
          height: 350
        });
      }
    });
}
  
export function notification_startPromptNotification() {
  chrome.notifications.create('startPromptNotification', {
    type: 'basic',
    iconUrl: 'logo.png',
    title: 'UX-Tracking: Sessão de captura iniciada',
    message: 'A sessão de captura será ativada na próxima aba acessada.\nAbra agora a página onde deseja iniciar a sessão.',
    priority: 2
});
}


export function notification_captureStartedNotification() {
  chrome.notifications.create('captureStartedNotification', {
    type: 'basic',
    iconUrl: 'logo.png',
    title: 'UX-Tracking: Captura iniciada',
    message: 'A coleta de dados está em andamento.\nPara encerrar a captura acesse o menu de acesso da extensão Uxtracking .',
    priority: 2
});
}