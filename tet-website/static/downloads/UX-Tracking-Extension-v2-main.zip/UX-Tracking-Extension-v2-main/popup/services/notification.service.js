export function notification_login() {
    chrome.notifications.create('loginNotification', {
      type: 'basic',
      iconUrl: 'logo.png',
      title: 'UX-Tracking: Login required!',
      message: 'Log in to start capture!\nClick the button below or open the extension menu.',
      buttons: [{ title: 'Login' }]
    });
  
    chrome.notifications.onButtonClicked.addListener(function (clickedNotificationId, buttonIndex) {
      if (clickedNotificationId === 'loginNotification' && buttonIndex === 0) {
        chrome.windows.create({
          url: 'popup/index.html',
          type: 'popup',
          width: 320,
          height: 480
        });
      }
    });
}
  
export function notification_startPromptNotification() {
  chrome.notifications.create('startPromptNotification', {
    type: 'basic',
    iconUrl: 'logo.png',
    title: 'UX-Tracking: Capture session started',
    message: 'The capture session will be activated on the next tab accessed.\nOpen the page where you want to start the session now.',
    priority: 2
});
}


export function notification_captureStartedNotification() {
  chrome.notifications.create('captureStartedNotification', {
    type: 'basic',
    iconUrl: 'logo.png',
    title: 'UX-Tracking: Capture started',
    message: 'Data collection is in progress.\nTo end the capture, access the extension menu.',
    priority: 2
});
}