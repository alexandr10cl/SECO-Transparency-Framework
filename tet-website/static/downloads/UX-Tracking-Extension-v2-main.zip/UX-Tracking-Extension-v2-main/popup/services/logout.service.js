import removeSessionData from "../utils/removeSessionData.js";
import stopRecording from "../utils/stopRecording.js";

export default function logoutService() {
    document.getElementById('logout').addEventListener('click', function () {
        removeSessionData()
        stopRecording()
        document.getElementById("divLogin").style.display = "block";
        document.getElementById("mainContent").style.display = "none";
        document.getElementById("mainContentCodeAcess").style.display = "none";
        cleanupInputsAndSensors()
        });
}

function cleanupInputsAndSensors() {
    console.debug("[UXT] Limpando inputs e sensores...");

    // Mouse
    document.removeEventListener('mousemove', storeMouseData);
    document.removeEventListener('click', storeMouseData);
    document.removeEventListener('wheel', storeMouseData);

    // Teclado
    document.removeEventListener('keydown', handleKeyDown);

    // WebGazer (olho/câmera)
    if (typeof webgazer !== 'undefined') {
        try {
            webgazer.pause();
            webgazer.setGazeListener(null);
            webgazer.end();
            console.debug("[UXT] WebGazer parado.");
        } catch (e) {
            console.warn("[UXT] Erro ao parar WebGazer:", e);
        }
    }

    // Reconhecimento de voz
    if (window.recognitionInstance) {
        try {
            window.recognitionInstance.stop();
            window.recognitionInstance = null;
            console.debug("[UXT] Reconhecimento de voz parado.");
        } catch (e) {
            console.warn("[UXT] Erro ao parar reconhecimento de voz:", e);
        }
    }

    // Intervalos e timeouts
    clearInterval(faceInterval);
    clearInterval(eyeInterval);
    clearInterval(sendInterval);
    clearTimeout(freezeInterval);
    clearTimeout(mouseTimeout);

    // Iframe
    if (iframe && iframe.parentNode) {
        iframe.parentNode.removeChild(iframe);
    }

    // Limpar dicionário de interações
    Object.keys(dataDict).forEach(key => dataDict[key] = []);
}