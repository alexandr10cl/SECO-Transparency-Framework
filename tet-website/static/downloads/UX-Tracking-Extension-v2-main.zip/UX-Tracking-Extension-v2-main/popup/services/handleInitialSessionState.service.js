// Ao inicializar pela primeira vez entao recarregue a ultima navegabilidade
// de pagina ou dados

import { interface_login, interface_loginAutenticat, interface_loginCode } from "./interfaces.service.js";

export async function handleInitialSessionState(data) {
    const hasToken = !!data.authToken;
    const sessionCode = !!data.isCodeSession;
    const sessionCodeValue = data.codeSession;

    if (hasToken && sessionCode) {
        interface_loginCode()
        
        const btn = document.getElementById("__StartCodeButton__");
        btn.textContent = sessionCode ? "Encerrar sessão" : "Iniciar sessão";
        btn.style.backgroundColor = sessionCode ? "rgba(255, 0, 4, 1)" : "rgba(108, 117, 125, 1)";
        document.getElementById('codeSessionB').value = sessionCodeValue??"";
        return;
    }

    if (hasToken && !sessionCode) {
        interface_loginAutenticat()
        return;
    }

    
    interface_login()
}
