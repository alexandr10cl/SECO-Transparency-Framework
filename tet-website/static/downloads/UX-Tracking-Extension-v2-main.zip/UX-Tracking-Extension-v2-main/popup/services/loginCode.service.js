import { getBaseUrl } from "../utils/getBaseUrl.js";

export async function loginCodeService(status) {
  let baseUrl = await getBaseUrl()
    const btn = document.getElementById("__StartCodeButton__");
    const code = $("#codeSessionB").val();

    if (!code && !status) return false;

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const pageUrl = tab?.url || "https://exemplo.com";

    const payload = {
      userId: "0",
      tool: "ux-tracker",
      initialMetadata: { pageUrl },
      integration: { cod: code }
    };

    $.ajax({
      url: baseUrl + "/auth/login-code",
      method: "POST",
      contentType: "application/json",
      data: JSON.stringify(payload),
      success: function (authToken) {
        if (!authToken.sessionId || !authToken.access_token) return false;
        
        chrome.storage.sync.set({
          sessionId: authToken.sessionId,
          authToken: authToken.access_token,
          authID: authToken.userId,
          isCodeSession: true,
          codeSession: code,
          record: true
        });
        btn.textContent = "Encerrar sessão" 
        document.getElementById("__StartCodeButton__").style.backgroundColor = "rgba(255, 0, 4, 1)";
        chrome.runtime.sendMessage({ type: "showCaptureNotification" });
        chrome.runtime.sendMessage({ type: "startRecordingCode" });
      },
      error: function (xhr, status, err) {
        return false
      }
    });
  }