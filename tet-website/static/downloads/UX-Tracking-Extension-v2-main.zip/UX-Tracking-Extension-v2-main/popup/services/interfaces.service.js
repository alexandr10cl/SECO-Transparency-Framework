export function interface_loginCode() {
    document.getElementById('mainContentCodeAcess').style.display = "block";
    document.getElementById('mainContent').style.display = "none";
    document.getElementById('divLogin').style.display = "none";
}

export function interface_login() {
    document.getElementById('mainContentCodeAcess').style.display = "none";
    document.getElementById("mainContent").style.display = "none";
    document.getElementById("divLogin").style.display = "block";
}

export function interface_loginAutenticat() {
    document.getElementById('mainContentCodeAcess').style.display = "none";
    document.getElementById("mainContent").style.display = "block";
    document.getElementById("divLogin").style.display = "none";
}