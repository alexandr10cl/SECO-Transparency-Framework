import removeSessionData from "../utils/removeSessionData.js";
import stopRecording from "../utils/stopRecording.js";

export default async function switchModeLoginCode(status) {
    const btn = document.getElementById("__StartCodeButton__");
    if (status) {
        await stopRecording()
        await removeSessionData().then((e) => {
            btn.style.backgroundColor = "rgba(108, 117, 125, 1)";
            btn.textContent = "Iniciar sessão";
            document.getElementById('codeSessionB').value = "";

        })
        return;
    }
  btn.textContent = "Encerrar sessão";
  btn.style.backgroundColor = status?"rgba(255, 0, 4, 1)":"rgba(108, 117, 125, 1)";
}