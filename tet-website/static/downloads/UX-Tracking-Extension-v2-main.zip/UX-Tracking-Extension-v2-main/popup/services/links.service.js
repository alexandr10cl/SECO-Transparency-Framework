export default function linksService() {
    const links = document.querySelectorAll("a");
    links.forEach(link => {
      const location = link.getAttribute('href');
      if (location !== "#" && link.id !== "accessByCode") {
        link.addEventListener('click', (e) => {
          e.preventDefault();
          chrome.tabs.create({ active: true, url: location });
        });
      }
    });
  
}