// DEBUGG MODE use essa rota
// const serverUrl = "http://localhost:3000";
// Staging Utilize esa
const serverUrl = "https://uxt-stage.liis.com.br";
// Prod Utilize esa
// const serverUrl = "https://uxt.liis.com.br";


var datetime = new Date();
let sessionCreated = false;
var sessionId = '';
var userId = '';
var token = '';
var isCodeSession = false;
chrome.storage.sync.get(['authToken', 'authID','isCodeSession','sessionId'], function (data) {
    userId = data.authID;
    token = data.authToken;
    isCodeSession = data.isCodeSession;
    if (data.sessionId) {
        sessionId = data.sessionId;
    }
});

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    switch (request.type) {
        case "showCaptureNotification":
            chrome.notifications.create('captureStartedNotification', {
                type: 'basic',
                iconUrl: 'logo.png',
                title: 'UX-Tracking: Captura iniciada',
                message: 'A coleta de dados está em andamento.\nPara encerrar a captura acesse o menu de acesso da extensão Uxtracking .',
                priority: 2
            });

            chrome.notifications.onButtonClicked.addListener((notifId, buttonIndex) => {
                if (notifId === 'captureStartedNotification' && buttonIndex === 0) {
                    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                        if (tabs[0] && tabs[0].id) {
                            chrome.tabs.sendMessage(tabs[0].id, { type: "stopRecording" });
                        }
                    });
                    chrome.notifications.clear('captureStartedNotification');
                }
            });
            break;
        
        case "getServerUrl":
            sendResponse({ reply: serverUrl });
            break;
        case "startRecording":
            chrome.storage.sync.get(['authToken', 'authID','isCodeSession','sessionId'], function (data) {
                userId = data.authID;
                token = data.authToken;
                isCodeSession = data.isCodeSession;
                if (data.sessionId) {
                    sessionId = data.sessionId;
                }
            });
            chrome.notifications.create('startPromptNotification', {
                type: 'basic',
                iconUrl: 'logo.png',
                title: 'UX-Tracking: Sessão de captura iniciada',
                message: 'A sessão de captura será ativada na próxima aba acessada.\nAbra agora a página onde deseja iniciar a sessão.',
                priority: 2
            });

            // if (sessionId) {
            //     return true;
            // }

            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                    if (tabs.length === 0 || !tabs[0].url) {
                        console.error("Nenhuma aba ativa encontrada.");
                        return;
                    }

                    const pageUrl = tabs[0].url;

                    const payload = {
                        userId: userId,
                        tool: "ux-tracker",
                        initialMetadata: {
                            pageUrl: pageUrl
                        }
                    };
                    fetch(`${serverUrl}/data/create-session`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "Authorization": `Bearer ${token}`
                        },
                        body: JSON.stringify(payload)
                    })
                        .then(async res => {
                            const responseJson = await res.json();

                            if (!responseJson.sessionId) {
                                console.error("sessionId não retornado pela API");
                                return;
                            }
                            sessionId = responseJson.sessionId;
                            chrome.storage.sync.set({ sessionId: sessionId }, () => {});

                        })
                        .catch(err => {
                            console.error("Erro ao criar sessão:", err);
                        });
                });
            return true;

        case "startRecordingCode":
            chrome.storage.sync.get(['authToken', 'authID','isCodeSession','sessionId'], function (data) {
                userId = data.authID;
                token = data.authToken;
                isCodeSession = data.isCodeSession;
                if (data.sessionId) {
                    sessionId = data.sessionId;
                }
            });
            chrome.notifications.create('startPromptNotification', {
                type: 'basic',
                iconUrl: 'logo.png',
                title: 'UX-Tracking: Sessão de captura iniciada',
                message: 'A sessão de captura será ativada na próxima aba acessada.\nAbra agora a página onde deseja iniciar a sessão.',
                priority: 2
            });
            return true;
        case "stopRecording":
            // Enviar a mensagem para o content.js
            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                if (tabs.length > 0 && tabs[0].id) {
                    chrome.tabs.sendMessage(tabs[0].id, { type: "stopRecording" }, function (response) {
                        if (chrome.runtime.lastError) {
                            // O content script não está ativo ou ocorreu outro erro
                        } else {
                        }
                    });
                } else {
                }
            });
            chrome.storage.sync.remove(['sessionId']);

            break;
        case "inferencia":
            sendFace(request.data)
                .then(responseData => sendResponse(JSON.parse(responseData)))
                .catch(error => console.error("Erro no reconhecimento facial: ", error));
            return true; // Mantém sendResponse ativo
        case "error":
            console.error(`Erro recebido: ${request.message}`);
            break;
        case "log":
            console.error(`Log recebido: ${request.message}`);
            break;
        case "sendData":
            capture(request.data, request.pageHeight, request.pageMeta);
            break;
    }
    return true; // Para tratamento assíncrono de sendResponse
});

function capture(data, pageHeight, pageMeta) {
    chrome.windows.getCurrent(function (win) {
        chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
            if (!tabs || !tabs[0] || !tabs[0].url) return console.error('Aba inválida');

            const url = new URL(tabs[0].url);
            const fullUrl = url.href;

            chrome.storage.sync.get(['sessionId', 'authID'], function (syncData) {
                const currentSessionId = syncData.sessionId || null;
                const currentUserId = syncData.authID || null;

                chrome.tabs.captureVisibleTab(win.id, { format: "jpeg", quality: 25 }, function (screenshotUrl) {
                    if (!screenshotUrl) return console.error("Falha ao capturar tela.");

                    const content = {
                        interactions: data,
                        tools: "ux-tracker",
                        sessionId: currentSessionId,
                        metadata: {
                            userID: currentUserId,
                            dateTime: new Date().toISOString(),
                            image: screenshotUrl,
                            height: pageHeight,
                            site: fullUrl,
                            pageWidth: pageMeta?.pageWidth || 0,
                            pageTitle: pageMeta?.pageTitle || null,
                            pageDescription: pageMeta?.pageDescription || null
                        }
                    };

                    post(content);
                });
            });
        });
    });
}

async function post(content) {
    const interactions = [];
    const length = content.interactions.type.length;

    for (let i = 0; i < length; i++) {
        interactions.push({
            type: content.interactions.type[i],
            element: content.interactions.id?.[i] || '',
            timestamp: new Date().toISOString(),
            x: content.interactions.x?.[i] || 0,
            y: content.interactions.y?.[i] || 0,
            scrollPos: content.interactions.scroll?.[i] || 0,
            data: content.interactions.value?.[i] != null ? JSON.stringify(content.interactions.value[i]) : null
        });
    }

    const body = {
        userId: content.metadata.userID,
        sessionId: content.sessionId,
        tool: content.tools,
        image: content.metadata.image,
        imageScrollPos: content.metadata.height,
        metadata: {
            pageUrl: content.metadata.site,
            pageHeight: content.metadata.height || 0,
            pageWidth: content.metadata.pageWidth || 0,
            pageTitle: content.metadata.pageTitle || null,
            pageDescription: content.metadata.pageDescription || null
        },  
        interactions
    };

    try {
        const response = await fetch(`${serverUrl}/data/receiver`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            },
            body: JSON.stringify(body)
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error("Erro ao enviar dados:", response.status, errorText);
        }
    } catch (error) {
        console.error("Erro ao enviar dados para o servidor:", error);
    }
}


async function sendFace(image) {
    const response = await fetch(`${serverUrl}/inference/face_expression`, {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": `Bearer ${token}`
         },
        body: new URLSearchParams({ data: image })
    });
    return response.text();
}

function notifyCaptureStarted() {
    chrome.notifications.create('captureStartedNotification', {
        type: 'basic',
        iconUrl: 'logo.png',
        title: 'UX-Tracking: Captura iniciada',
        message: 'A coleta de dados está em andamento.\nClique abaixo para encerrar a captura.',
        buttons: [{ title: 'Encerrar captura' }],
        priority: 2
    });

    chrome.notifications.onButtonClicked.addListener((notifId, buttonIndex) => {
        if (notifId === 'captureStartedNotification' && buttonIndex === 0) {
            chrome.runtime.sendMessage({ type: "stopRecording" });
            chrome.notifications.clear('captureStartedNotification');
        }
    });
}